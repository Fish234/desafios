n = ARGV[0].to_i #numero
suma_pares = 0

n.times do |i|
    par = (2*(i+1))
    suma_pares += par
end

print suma_pares