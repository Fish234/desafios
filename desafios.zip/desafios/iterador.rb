50.times do |i|
    puts "Iteración #{i}"    
end