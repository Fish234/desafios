num = ARGV[0].to_i

#El cero si es par 

num.times do |i|
    if i %2 == 1
        print "\t#{i}"
    end
end